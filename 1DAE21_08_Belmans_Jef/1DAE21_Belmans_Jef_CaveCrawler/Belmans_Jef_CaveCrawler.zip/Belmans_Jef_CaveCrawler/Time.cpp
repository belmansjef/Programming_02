#include "Time.h"

float Time::time{ 0.0f };
float Time::deltaTime{ 0.0f };
