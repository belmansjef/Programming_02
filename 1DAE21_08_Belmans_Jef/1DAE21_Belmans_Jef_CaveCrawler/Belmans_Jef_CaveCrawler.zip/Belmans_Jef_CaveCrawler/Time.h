#pragma once
class Time
{
public:
	static float time;
	static float deltaTime;
};

